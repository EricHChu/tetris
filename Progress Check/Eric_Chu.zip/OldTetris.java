import javax.swing.*;
import java.awt.*;
import java.util.Arrays;
import java.awt.event.*;
import javax.sound.sampled.*;

/**
 * Tetris - A single player game about stacking and clearing monominos
 * @author Eric
 * @version June 2022
 */
public class Tetris{
    public static JFrame gameWindow;
    public static Color[] colors = {Color.cyan,Color.blue,Color.orange,Color.yellow,Color.green,Color.magenta,Color.red};
    JPanel panel;
    JButton easy;
    JButton medium;
    JLabel tron;
    JLabel select;
    GraphicsPanel canvas;
    JLabel scoreDisplay;
    Font font = new Font("Monospaced", Font.PLAIN, 40);
    Font bigFont = new Font("Monospaced", Font.BOLD, 60);
    Font smallFont = new Font("Monospaced", Font.BOLD, 20);
    Font tronFont = new Font("Monospaced", Font.PLAIN, 60);
    Font buttonFont = new Font("Monospaced", Font.PLAIN, 20);
    DirectionKeyListener keyListener;
    public static int currentColor = 0;
    public static int timerTime = Const.BASETIME;
    public static String currentAction = "none";
    public static boolean hardDrop = false;
    public static int score = 0;

    public static boolean play = true;
    
    Sound loseSound = new Sound("loser.wav");

    //2D Arrays For Each Player
    public static int[][][] gameBoard = new int[Const.BOARDY][Const.BOARDX][2];
    public static int[][] currentPiece = new int[Const.BOARDY][Const.BOARDX];
//------------------------------------------------------------------------------
    Tetris(){
        for (int i = 0; i < Const.BOARDY;i++){
            for(int a = 0; a < Const.BOARDX;a++){
                Arrays.fill(gameBoard[i][a],0);
            }
            Arrays.fill(currentPiece[i],0);
        }
        gameWindow = new JFrame("Game Window");
        gameWindow.setSize(Const.WIDTH, Const.HEIGHT);
        gameWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        panel = new JPanel();
        panel.setLayout(new GridLayout());
        panel.setBackground(Color.black);
        gameWindow.add(panel);
            
        tron = new JLabel("Tetris");
        tron.setFont(tronFont);
        tron.setHorizontalAlignment(JLabel.CENTER);
        tron.setVerticalAlignment(JLabel.TOP);
        tron.setForeground(Color.white);
        panel.add(tron);
        
        easy = new JButton("Play");
        easy.setActionCommand("easy");
        medium = new JButton("Controls");
        medium.setActionCommand("medium");
        // Add a listener to the button (makes the button active)
        easy.addActionListener(new ButtonListener());
        medium.addActionListener(new ButtonListener());  
        easy.setFont(buttonFont);
        medium.setFont(buttonFont);
        panel.add(easy);
        panel.add(medium);
        
        canvas = new GraphicsPanel();
        
        keyListener = new DirectionKeyListener();
        canvas.addKeyListener(keyListener);
        loseSound.addLineListener(new LoseSoundListener());
        //gameWindow.add(canvas);
        gameWindow.setVisible(true);
    }
//------------------------------------------------------------------------------
    public void runGameLoop(){
        resetGame(gameBoard,currentPiece);
        while (play == true){
            int timer = 0;
            boolean dead = false;
            int x = 4;
            int y = 0;
            currentPiece[y][x] = 1;
            currentColor = (int)Math.round(Math.random()*6);
            while (dead == false) {
                gameWindow.repaint();
                try {Thread.sleep(Const.FRAME_PERIOD);} catch(Exception e){}
                timer++;
                currentPiece[y][x] = 0;
                if(hardDrop == true){
                    boolean dropped = false;
                    while(dropped != true){
                        y++;
                        if(y >= Const.BOARDY){
                            y--;
                            gameBoard[y][x][0] = 1;
                            gameBoard[y][x][1] = currentColor;
                            x = 4;
                            y = 0;
                            currentColor = (int)Math.round(Math.random()*6);
                            int line = detectLine(gameBoard);
                            System.out.println(line);
                            dropped = true;
                            if(line != -1){
                                score = score + 100;
                                clearLine(gameBoard,line);
                            }
                        }else if(gameBoard[y][x][0] == 1){
                            y--;
                            gameBoard[y][x][0] = 1;
                            gameBoard[y][x][1] = currentColor;
                            x = 4;
                            y = 0;
                            currentColor = (int)Math.round(Math.random()*6);
                            int line = detectLine(gameBoard);
                            System.out.println(line);
                            dropped = true;
                            if(line != -1){
                                score = score + 100;
                                clearLine(gameBoard,line);
                            }
                        }
                    }
                    hardDrop = false;
                }
                if(timer >= timerTime){
                    y++;
                    if(y >= Const.BOARDY){
                        y--;
                        gameBoard[y][x][0] = 1;
                        gameBoard[y][x][1] = currentColor;
                        x = 4;
                        y = 0;
                        currentColor = (int)Math.round(Math.random()*6);
                        int line = detectLine(gameBoard);
                        System.out.println(line);
                        if(line != -1){
                            clearLine(gameBoard,line);
                        }
                    }else if(gameBoard[y][x][0] == 1){
                        y--;
                        gameBoard[y][x][0] = 1;
                        gameBoard[y][x][1] = currentColor;
                        x = 4;
                        y = 0;
                        currentColor = (int)Math.round(Math.random()*6);
                        int line = detectLine(gameBoard);
                        System.out.println(line);
                        if(line != -1){
                            clearLine(gameBoard,line);
                        }
                    }
                    timer = 0;
                }
                if (currentAction.equals("left")){
                    x--;
                    if(x < 0){
                        x++;
                    }else if(gameBoard[y][x][0] == 1){
                        x++;
                    }
                    currentAction = "none";
                }else if (currentAction.equals("right")){
                    x++;
                    if(x > Const.BOARDX - 1){
                        x--;
                    }else if(gameBoard[y][x][0] == 1){
                        x--;
                    }
                    currentAction = "none";
                }
                if(y >= Const.BOARDY){
                    gameBoard[y][x][0] = 1;
                    x = 4;
                    y = 0;
                }
                currentPiece[y][x] = 1;
                /*if(gameBoard[y][x][0] == 1){
                    dead = true;
                    if (loseSound.isRunning()){ 
                        loseSound.stop();               
                        loseSound.flush();              
                        loseSound.setFramePosition(0);  
                    }
                    loseSound.start(); 
                }*/
            }
            if (dead){
                score++;
                currentAction = resetGame(gameBoard,currentPiece);
            }
            if (score < -1){
                play = false;
            }
            gameWindow.repaint();
        }
    }
//------------------------------------------------------------------------------
    public class DirectionKeyListener implements KeyListener{
        public void keyPressed(KeyEvent e){
            int key = e.getKeyCode();
            if (key == KeyEvent.VK_LEFT){
                currentAction = "left";
            } else if (key == KeyEvent.VK_RIGHT){
                currentAction = "right";
            } else if (key == KeyEvent.VK_UP){
                currentAction = "clockwise";
            }
            if (key == KeyEvent.VK_DOWN){
                timerTime = Const.BASETIME/20;
            }
            if(key == KeyEvent.VK_SPACE){
                hardDrop = true;
            }
        }
        public void keyReleased(KeyEvent e){
            int key = e.getKeyCode();
            if(key == KeyEvent.VK_DOWN){
                timerTime = Const.BASETIME;
            }
        }
        public void keyTyped(KeyEvent e){
        }
    }
//--------------------------------------------------------------------
    public class GraphicsPanel extends JPanel {
        public GraphicsPanel(){
            setFocusable(true);
            requestFocusInWindow();
        }
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.setColor(Color.black);
            g.fillRect((Const.WIDTH/2) - ((Const.BOARDX*Const.SQUARE_SIZE)/2),0,Const.BOARDX*Const.SQUARE_SIZE, Const.BOARDY*Const.SQUARE_SIZE);
            for(int j = 0; j < Const.BOARDY; j++){
                for(int i = 0; i < Const.BOARDX;i++){
                    if(gameBoard[j][i][0] != 0){
                        g.setColor(colors[gameBoard[j][i][1]]);
                        g.fillRect((Const.WIDTH/2) - ((Const.BOARDX*Const.SQUARE_SIZE)/2) + i*Const.SQUARE_SIZE,j*Const.SQUARE_SIZE,Const.SQUARE_SIZE,Const.SQUARE_SIZE);
                    }
                }
            }
            g.setColor(Color.red);
            for(int j = 0; j < Const.BOARDY; j++){
                for(int i = 0; i < Const.BOARDX;i++){
                    if(currentPiece[j][i] != 0){
                        g.setColor(colors[currentColor]);
                        g.fillRect((Const.WIDTH/2) - ((Const.BOARDX*Const.SQUARE_SIZE)/2) + i*Const.SQUARE_SIZE,j*Const.SQUARE_SIZE,Const.SQUARE_SIZE,Const.SQUARE_SIZE);
                    }
                }
            }
            g.setColor(Color.white);
            g.setFont(font);
            g.drawString(String.valueOf(score), Const.WIDTH/2 - 15, 100);
            g.setFont(bigFont);
            if (play == false){
                g.setColor(Color.black);
                g.fillRect(0,0,Const.BOARDX*Const.SQUARE_SIZE, Const.BOARDY*Const.SQUARE_SIZE);
                g.setColor(Color.red);
                g.drawString("Game Over.", Const.WIDTH/2 - 160, Const.HEIGHT/2 - 75);
                //g.drawString("Blue:" + p1Score + " Red:" + p2Score, Const.WIDTH/2 - 210, Const.HEIGHT/2 +25);
                g.setColor(Color.white);
                g.setFont(smallFont);
                g.drawString("Credits: Erin Chin, Eric Chu, Jaclyn Wang", Const.WIDTH/2 - 240, Const.HEIGHT-100);
            }
        }
    }
//-------------------------------------------------------------------------------------------
    public class ButtonListener implements ActionListener{
        public void actionPerformed(ActionEvent e){
            if("easy".equals(e.getActionCommand())){
                gameWindow.remove(panel);
                gameWindow.add(canvas);
                gameWindow.repaint();
                gameWindow.setVisible(true);
                canvas.requestFocusInWindow();
            }else if("medium".equals(e.getActionCommand())){
                gameWindow.remove(panel);
                gameWindow.add(canvas);
                gameWindow.repaint();
                gameWindow.setVisible(true);
                canvas.requestFocusInWindow();
            }
        }
    }
//-------------------------------------------------------------------------------------------
    public class LoseSoundListener implements LineListener { 
        public void update(LineEvent event) { 
            if (event.getType() == LineEvent.Type.STOP) { 
                loseSound.flush();                  
                loseSound.setFramePosition(0);     
            } 
        } 
    }    
//------------------------------------------------------------------------------
    public static void main(String[] args) {
        Tetris game = new Tetris();
        while(play == true){
           game.runGameLoop();
           currentAction = resetGame(gameBoard,currentPiece);
           score = 0;
           play = true;
           
        }
    }
    public static String resetGame(int[][][] gBoard1, int[][] gBoard2){
        for (int i = 0; i < Const.BOARDY;i++){
            for(int a = 0; a < Const.BOARDX;a++){
                Arrays.fill(gBoard1[i][a],0);
            }
            Arrays.fill(gBoard2[i],0);
        }
        return "none";
    }
    public static void clearLine(int[][][] board,int line){
        for(int a = 1; a < line + 2;a++){
            for(int i = 0; i < Const.BOARDX;i++){
                if(line-a == -1){
                    board[line-a+1][i][0] = 0;
                    board[line-a+1][i][1] = 0;
                }else{
                    board[line-a+1][i][0] = board[line-a][i][0];
                    board[line-a+1][i][1] = board[line-a][i][1];
                }
            }
        }
    }
    public static int detectLine(int[][][] board){
        for(int i = 0;i < Const.BOARDY;i++){
            for(int a = 0; a < Const.BOARDX;a++){
                if(board[i][a][0] == 1){
                    if(a == Const.BOARDX - 1){
                        return i;
                    }
                }else{
                    a = Const.BOARDX;
                }
            }
        }
        return -1;
    }
}
