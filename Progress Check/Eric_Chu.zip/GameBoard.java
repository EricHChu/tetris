import java.util.Arrays;

public class GameBoard{
    private int[][][] gameBoard = new int[Const.BOARDY][Const.BOARDX][2];
    
    public GameBoard(){
        for (int i = 0; i < Const.BOARDY;i++){
            for(int a = 0; a < Const.BOARDX;a++){
                Arrays.fill(this.gameBoard[i][a],0);
            }
        }
    }
    public int[][][] getGameBoard(){
        return this.gameBoard;
    }
    public void setVal(int y, int x, int type, int val){
        this.gameBoard[y][x][type] = val;
    }
    public int detectLine(){
        for(int i = 0;i < Const.BOARDY;i++){
            for(int a = 0; a < Const.BOARDX;a++){
                if(this.gameBoard[i][a][0] == 1){
                    if(a == Const.BOARDX - 1){
                        return i;
                    }
                }else{
                    a = Const.BOARDX;
                }
            }
        }
        return -1;
    }
    public void clearLine(int line){
        for(int a = 1; a < line + 2;a++){
            for(int i = 0; i < Const.BOARDX;i++){
                if(line-a == -1){
                    this.gameBoard[line-a+1][i][0] = 0;
                    this.gameBoard[line-a+1][i][1] = 0;
                }else{
                    this.gameBoard[line-a+1][i][0] = this.gameBoard[line-a][i][0];
                    this.gameBoard[line-a+1][i][1] = this.gameBoard[line-a][i][1];
                }
            }
        }
    }
}