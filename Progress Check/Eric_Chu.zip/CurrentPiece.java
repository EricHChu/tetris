import java.util.Arrays;

public class CurrentPiece{
    private int x;
    private int y;
    private int type;
    private int orientation;
    
    public CurrentPiece(){
        this.type = (int)Math.round(Math.random()*6);
        this.x = 4;
        if(this.type >=4){
            this.y = 1;
        }else{
            this.y = 0;
        }
    }
    public int getX(){
        return this.x;
    }
    public int getY(){
        return this.y;
    }
    public int getType(){
        return this.type;
    }
    public boolean moveDown(GameBoard gBoard){
        this.y = this.y + 1;
        if(this.y >= Const.BOARDY){
            this.y = this.y - 1;
            return true;
        }else if(gBoard.getGameBoard()[this.y][this.x][0] == 1){
            this.y = this.y - 1;
            return true;
        }
        return false;
    }
    public void moveRight(GameBoard gameBoard){
        this.x = this.x + 1;
        if(x >= Const.BOARDX){
            this.x = this.x - 1;
        }else if(gameBoard.getGameBoard()[y][x][0] == 1){
            this.x = this.x - 1;
        }
    }
    public void moveLeft(GameBoard gameBoard){
        this.x = this.x - 1;
        if(x < 0){
            this.x = this.x + 1;
        }else if(gameBoard.getGameBoard()[y][x][0] == 1){
            this.x = this.x + 1;
        }
    }
}