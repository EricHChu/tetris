import javax.swing.*;
import java.awt.*;
import java.util.Arrays;
import java.awt.event.*;
import javax.sound.sampled.*;

/**
 * Tetris - A single player game about stacking and clearing monominos
 * @author Eric
 * @version June 2022
 */
public class Tetris{
    public static JFrame gameWindow;
    public static Color[] colors = {Color.cyan,Color.blue,Color.orange,Color.yellow,Color.green,Color.magenta,Color.red};
    JPanel panel;
    JButton playButton;
    JButton instructions;
    JLabel tron;
    JLabel select;
    GraphicsPanel canvas;
    JLabel scoreDisplay;
    Font font = new Font("Monospaced", Font.PLAIN, 40);
    Font bigFont = new Font("Monospaced", Font.BOLD, 60);
    Font smallFont = new Font("Monospaced", Font.BOLD, 20);
    Font tronFont = new Font("Monospaced", Font.PLAIN, 60);
    Font buttonFont = new Font("Monospaced", Font.PLAIN, 20);
    DirectionKeyListener keyListener;
    public static int timerTime = Const.BASETIME;
    public static String currentAction = "none";
    public static boolean hardDrop = false;
    public static int score = 0;
    public static boolean play = true;
    public static boolean button;
    
    Sound loseSound = new Sound("loser.wav");
    Sound music = new Sound("am321.wav");

    //Classes For The Current Piece And The Game Board
    public static GameBoard gameBoard = new GameBoard();
    public static CurrentPiece currentPiece = new CurrentPiece();
//------------------------------------------------------------------------------
    Tetris(){
        gameWindow = new JFrame("Game Window");
        gameWindow.setSize(Const.WIDTH, Const.HEIGHT);
        gameWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        panel = new JPanel();
        panel.setLayout(new GridLayout());
        panel.setBackground(Color.black);
        gameWindow.add(panel);
            
        tron = new JLabel("Tetris");
        tron.setFont(tronFont);
        tron.setHorizontalAlignment(JLabel.CENTER);
        tron.setVerticalAlignment(JLabel.TOP);
        tron.setForeground(Color.white);
        panel.add(tron);
        
        playButton = new JButton("Play");
        playButton.setActionCommand("play");
        instructions = new JButton("Instructions");
        instructions.setActionCommand("instructions");
        // Add a listener to the button (makes the button active)
        playButton.addActionListener(new ButtonListener());
        instructions.addActionListener(new ButtonListener());  
        playButton.setFont(buttonFont);
        instructions.setFont(buttonFont);
        panel.add(playButton);
        panel.add(instructions);
        
        canvas = new GraphicsPanel();
        
        keyListener = new DirectionKeyListener();
        canvas.addKeyListener(keyListener);
        loseSound.addLineListener(new LoseSoundListener());
        //gameWindow.add(canvas);
        gameWindow.setVisible(true);
    }
//------------------------------------------------------------------------------
    public void runGameLoop(){
        while (play == true){
            button = true;
            int timer = 0;
            boolean dead = false;
            while(button){
                if(button != true){
                    System.out.println("Started!");
                }
            }
            music.start();
            music.loop();
            while (dead == false) {
                gameWindow.repaint();
                try {Thread.sleep(Const.FRAME_PERIOD);} catch(Exception e){}
                timer++;
                if(hardDrop == true){
                    boolean dropped = false;
                    while(dropped != true){
                        if(currentPiece.moveDown(gameBoard)){
                            gameBoard.setVal(currentPiece.getY(),currentPiece.getX(),0,1);
                            gameBoard.setVal(currentPiece.getY(),currentPiece.getX(),1,currentPiece.getType());
                            currentPiece = new CurrentPiece();
                            int line = gameBoard.detectLine();
                            System.out.println(line);
                            dropped = true;
                            if(line != -1){
                                score = score + 100;
                                gameBoard.clearLine(line);
                            }
                        }
                    }
                    hardDrop = false;
                }
                if(timer >= timerTime){
                    if(currentPiece.moveDown(gameBoard)){
                        gameBoard.setVal(currentPiece.getY(),currentPiece.getX(),0,1);
                        gameBoard.setVal(currentPiece.getY(),currentPiece.getX(),1,currentPiece.getType());
                        currentPiece = new CurrentPiece();
                        int line = gameBoard.detectLine();
                        System.out.println(line);
                        if(line != -1){
                            gameBoard.clearLine(line);
                        }
                    }
                    timer = 0;
                }
                if (currentAction.equals("left")){
                    currentPiece.moveLeft(gameBoard);
                    currentAction = "none";
                }else if (currentAction.equals("right")){
                    currentPiece.moveRight(gameBoard);
                    currentAction = "none";
                }
                /*if(gameBoard[y][x][0] == 1){
                    dead = true;
                    if (loseSound.isRunning()){ 
                        loseSound.stop();               
                        loseSound.flush();              
                        loseSound.setFramePosition(0);  
                    }
                    loseSound.start(); 
                }*/
            }
            if (dead){
                score++;
            }
            if (score < -1){
                play = false;
            }
            gameWindow.repaint();
        }
    }
//------------------------------------------------------------------------------
    public class DirectionKeyListener implements KeyListener{
        public void keyPressed(KeyEvent e){
            int key = e.getKeyCode();
            if (key == KeyEvent.VK_LEFT){
                currentAction = "left";
            } else if (key == KeyEvent.VK_RIGHT){
                currentAction = "right";
            } else if (key == KeyEvent.VK_UP){
                currentAction = "clockwise";
            }
            if (key == KeyEvent.VK_DOWN){
                timerTime = Const.BASETIME/20;
            }
            if(key == KeyEvent.VK_SPACE){
                hardDrop = true;
            }
        }
        public void keyReleased(KeyEvent e){
            int key = e.getKeyCode();
            if(key == KeyEvent.VK_DOWN){
                timerTime = Const.BASETIME;
            }
        }
        public void keyTyped(KeyEvent e){
        }
    }
//--------------------------------------------------------------------
    public class GraphicsPanel extends JPanel {
        public GraphicsPanel(){
            setFocusable(true);
            requestFocusInWindow();
        }
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.setColor(Color.black);
            g.fillRect((Const.WIDTH/2) - ((Const.BOARDX*Const.SQUARE_SIZE)/2),0,Const.BOARDX*Const.SQUARE_SIZE, Const.BOARDY*Const.SQUARE_SIZE);
            g.setColor(colors[currentPiece.getType()]);
            g.fillRect((Const.WIDTH/2) - ((Const.BOARDX*Const.SQUARE_SIZE)/2) + currentPiece.getX()*Const.SQUARE_SIZE,
                       currentPiece.getY()*Const.SQUARE_SIZE,
                       Const.SQUARE_SIZE,
                       Const.SQUARE_SIZE);
            int[][][] gBoard = gameBoard.getGameBoard();
            for(int j = 0; j < Const.BOARDY; j++){
                for(int i = 0; i < Const.BOARDX;i++){
                    if(gBoard[j][i][0] != 0){
                        g.setColor(colors[gBoard[j][i][1]]);
                        g.fillRect((Const.WIDTH/2) - ((Const.BOARDX*Const.SQUARE_SIZE)/2) + i*Const.SQUARE_SIZE,j*Const.SQUARE_SIZE,Const.SQUARE_SIZE,Const.SQUARE_SIZE);
                    }
                }
            }
            g.setColor(Color.white);
            g.setFont(font);
            g.drawString(String.valueOf(score), Const.WIDTH/2 - 15, 100);
        }
    }
//-------------------------------------------------------------------------------------------
    public class ButtonListener implements ActionListener{
        public void actionPerformed(ActionEvent e){
            if("play".equals(e.getActionCommand())){
                gameWindow.remove(panel);
                gameWindow.add(canvas);
                gameWindow.repaint();
                gameWindow.setVisible(true);
                canvas.requestFocusInWindow();
                button = false;
            }else if("instructions".equals(e.getActionCommand())){
                gameWindow.remove(panel);
                gameWindow.add(canvas);
                gameWindow.repaint();
                gameWindow.setVisible(true);
                canvas.requestFocusInWindow();
                button = false;
            }
        }
    }
//-------------------------------------------------------------------------------------------
    public class LoseSoundListener implements LineListener { 
        public void update(LineEvent event) { 
            if (event.getType() == LineEvent.Type.STOP) { 
                loseSound.flush();                  
                loseSound.setFramePosition(0);     
            } 
        } 
    }    
//------------------------------------------------------------------------------
    public static void main(String[] args) {
        Tetris game = new Tetris();
        while(play == true){
           game.runGameLoop();
           play = true;
        }
    }
}